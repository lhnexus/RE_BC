package odata.rebc.model;

import java.util.ArrayList;

public class EntitySetResp  {
	public String status;
	public String txid;
	public ArrayList<HouseLease> data;
}
