package odata.rebc.model;

import java.util.List;

public class REResults {
	public List<REHouse> results;
}
