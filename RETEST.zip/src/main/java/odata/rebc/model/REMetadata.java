package odata.rebc.model;

public class REMetadata {
	public String id;
	public String uri;
	public String type;
	
}
