package odata.rebc.model;

public class Transaction   {
	public String Timestamp;
	public String ID;
	public HouseLease Value;
}
