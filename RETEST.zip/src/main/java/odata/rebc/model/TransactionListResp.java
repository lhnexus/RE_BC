package odata.rebc.model;
 
import java.util.List;

public class TransactionListResp   {
	public String status;
	public List<Transaction> data;
	public String txid;
}
