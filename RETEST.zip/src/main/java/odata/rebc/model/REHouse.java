package odata.rebc.model;

public class REHouse {
	public REMetadata __metadata;
	public String Aoid;
	public String Xao;
	public String FyName; //":"��Դ��",
	public String XmName; //":"DEMO-04",
	public String Adress; //":"����",
	public String Postcode; //":""
}
