package odata.rebc.model;

public class REResp {
	public REResults d;
}
