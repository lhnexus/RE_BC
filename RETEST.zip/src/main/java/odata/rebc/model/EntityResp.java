package odata.rebc.model;

public class EntityResp  {
	public String status;
	public String txid;
	public HouseLease data;
}
