package odata.rebc.model;  


public class HouseLease   {
	private String UUID;
	private String PRO_NAME;
	private String ADDRESS;
	private float PRICE;
	private String LEASE_FROM;
	private String LEASE_TO;
	private String OWNER;
	private String TENANT;
	private String APPLIER;
	private String TERMS;
	private String STATUS;
	private String UPDATER;
	
	public HouseLease(String uUID) {
		super();
		UUID = uUID;
	}
	public String getUUID() {
		return UUID;
	}
	public void setUUID(String uUID) {
		UUID = uUID;
	}
	public String getPRO_NAME() {
		return PRO_NAME;
	}
	public void setPRO_NAME(String pRO_NAME) {
		PRO_NAME = pRO_NAME;
	}
	public String getADDRESS() {
		return ADDRESS;
	}
	public void setADDRESS(String aDDRESS) {
		ADDRESS = aDDRESS;
	}
	public float getPRICE() {
		return PRICE;
	}
	public void setPRICE(float pRICE) {
		PRICE = pRICE;
	}
	public String getLEASE_FROM() {
		return LEASE_FROM;
	}
	public void setLEASE_FROM(String lEASE_FROM) {
		LEASE_FROM = lEASE_FROM;
	}
	public String getLEASE_TO() {
		return LEASE_TO;
	}
	public void setLEASE_TO(String lEASE_TO) {
		LEASE_TO = lEASE_TO;
	}
	public String getOWNER() {
		return OWNER;
	}
	public void setOWNER(String oWNER) {
		OWNER = oWNER;
	}
	public String getTENANT() {
		return TENANT;
	}
	public void setTENANT(String tENANT) {
		TENANT = tENANT;
	}
	public String getAPPLIER() {
		return APPLIER;
	}
	public void setAPPLIER(String aPPLIER) {
		APPLIER = aPPLIER;
	}
	public String getTERMS() {
		return TERMS;
	}
	public void setTERMS(String tERMS) {
		TERMS = tERMS;
	}
	public String getSTATUS() {
		return STATUS;
	}
	public void setSTATUS(String sTATUS) {
		STATUS = sTATUS;
	}
	public String getUPDATER() {
		return UPDATER;
	}
	public void setUPDATER(String uPDATER) {
		UPDATER = uPDATER;
	}
}
